<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="dark_fireplace" tilewidth="80" tileheight="195" tilecount="1" columns="1">
 <image source="asset/decorates/dark_fireplace.png" width="80" height="195"/>
</tileset>
