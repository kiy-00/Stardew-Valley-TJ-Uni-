<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="tv_back" tilewidth="70" tileheight="117" tilecount="1" columns="1">
 <image source="asset/decorates/tv_back.png" width="70" height="117"/>
</tileset>
