<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="bed" tilewidth="80" tileheight="120" tilecount="1" columns="1">
 <image source="asset/useful_items/bed_2.png" width="80" height="120"/>
</tileset>
