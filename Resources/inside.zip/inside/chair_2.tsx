<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="chair_2" tilewidth="38" tileheight="70" tilecount="1" columns="1">
 <image source="asset/decorates/chair_2.png" width="38" height="70"/>
</tileset>
