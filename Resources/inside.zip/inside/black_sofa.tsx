<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="black_sofa" tilewidth="131" tileheight="80" tilecount="1" columns="1">
 <image source="asset/useful_items/black_sofa.png" width="131" height="80"/>
</tileset>
