<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="blue_sofa" tilewidth="128" tileheight="80" tilecount="1" columns="1">
 <image source="asset/useful_items/blue_sofa.png" width="128" height="80"/>
</tileset>
