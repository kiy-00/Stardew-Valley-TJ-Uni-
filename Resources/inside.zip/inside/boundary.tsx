<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="boundary" tilewidth="32" tileheight="32" tilecount="7" columns="7">
 <image source="boundary.png" width="224" height="32"/>
</tileset>
