<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.0" name="red_sofa_left" tilewidth="80" tileheight="108" tilecount="1" columns="1">
 <image source="asset/useful_items/red_sofa_left.png" width="80" height="108"/>
</tileset>
